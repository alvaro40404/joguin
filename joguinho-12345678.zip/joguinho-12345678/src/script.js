const BOARD_SIZE = 3;
let board = [];
let emptyTile = { x: 0, y: 0 };

function createBoard() {
  let num = 1;
  for (let y = 0; y < BOARD_SIZE; y++) {
    let row = [];
    for (let x = 0; x < BOARD_SIZE; x++) {
      if (num === BOARD_SIZE * BOARD_SIZE) {
        row.push(null);
        emptyTile = { x, y };
      } else {
        row.push(num);
      }
      num++;
    }
    board.push(row);
  }
}

function renderBoard() {
  const boardEl = document.getElementById("board");
  boardEl.innerHTML = "";
  board.forEach((row, y) => {
    row.forEach((num, x) => {
      const tile = document.createElement("div");
      tile.classList.add("tile");
      if (num === null) {
        tile.classList.add("empty");
      } else if (num === 1) {
        tile.classList.add("selected");
      }
      tile.innerText = num;
      tile.addEventListener("click", () => {
        const dx = Math.abs(emptyTile.x - x);
        const dy = Math.abs(emptyTile.y - y);
        if ((dx === 1 && dy === 0) || (dx === 0 && dy === 1)) {
          board[emptyTile.y][emptyTile.x] = num;
          board[y][x] = null;
          emptyTile.x = x;
          emptyTile.y = y;
          renderBoard();
        }
      });
      boardEl.appendChild(tile);
    });
  });
}

createBoard();
renderBoard();
